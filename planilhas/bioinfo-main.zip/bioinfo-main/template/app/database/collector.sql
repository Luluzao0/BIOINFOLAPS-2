CREATE TABLE `bioinfo`.`collector` (
                           `id` INT NOT NULL,
                           `first_name` VARCHAR(15) NOT NULL,
                           `last_name` VARCHAR(15) NOT NULL,
                           PRIMARY KEY (`id`)
) ENGINE = InnoDB;
