<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "",
    'user'  =>  "",
    'pass'  =>  "senha",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];
